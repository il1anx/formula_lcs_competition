%% Author: Stacey Savchenko Email: anastasiya.forte@gmail.com
% This script initializes vehicle parameters and runs Simulink models for
% torque vectoring and traction control design and simulation.
clear;
clc;
close all;

syms delta v
%% Parameters
% Vehicle
x = 0;
m = 450/2.2;  % vehicle mass, kg
Iz = 71.888; % vehicle moment of inertia about z, kg*m^2
L = 1.530;  % wheelbase, m
a = 0.783;  % CG from front axle, m
b = L-a;  % CG from rear axle, m
L = 1.530;  % wheelbase, m
h = 0.225;  % height of CG
t = 1.175;  % track, m
GR = 12.63;    % gear ratio (final drive)

% Tire and Road
C_alpha_f = 288.35;  % cornering stiffness (front)
C_alpha_r = 375.91;  % cornering stiffness (rear)
Cr = 0.015; % rolling resistance
mu = 1.4; % tire-road COF
Rw = 0.1993; % wheel radius, m

% Inputs
time = linspace(0,10,100);   % time (array), s

% Aerodynamic
rho_air = 1.225;    % air density, kg/m^3
Af = 1.153; % effective vehicle front area, m^2
Cd = x; % drag coefficient

% Other
g = 9.81;   % gravity, m/s^2
Mz_dTm_convertion = 2*Rw/GR/t;

%% Cornering Stiffness Curve Fitting

Tire_Fy = load('TireFy_LC0.csv');   %Lateral tire forces
slip_angle_tire = Tire_Fy(:,1); %deg
Fy50lbf = Tire_Fy(:,2);     %N
Fy100lbf = Tire_Fy(:,3);    %N
Fy150lbf = Tire_Fy(:,4);    %N
Fy200lbf = Tire_Fy(:,5);    %N
Fy250lbf = Tire_Fy(:,6);    %N

% Visualizing Tire Fy vs Slip Angle to find linear range
plot(slip_angle_tire,Fy250lbf);
title('F_y vs Slip Angle for LC0 250lbf Load');
ylabel('F_y, N');
xlabel('Absolute Slip Angle, deg');

%Line fitting 50lb load stiffness
slip_curve = slip_angle_tire(3:20,1);
Fy_curve50 = Fy50lbf(3:20,1);
Cornering_Tire50 = polyfit(slip_curve,Fy_curve50,1);
Cf(1) = Cornering_Tire50(1); %cornering stiffness of "front" which is the same as "rear"
%Line fitting 100lb load stiffness
Fy_curve100 = Fy100lbf(3:20,1);
Cornering_Tire100 = polyfit(slip_curve,Fy_curve100,1);
Cf(2) = Cornering_Tire100(1); %cornering stiffness of "front" which is the same as "rear"
%Line fitting 150lb load stiffness
Fy_curve150 = Fy150lbf(3:20,1);
Cornering_Tire150 = polyfit(slip_curve,Fy_curve150,1);
Cf(3) = Cornering_Tire150(1); %cornering stiffness of "front" which is the same as "rear"
%Line fitting 200lb load stiffness
Fy_curve200 = Fy200lbf(3:20,1);
Cornering_Tire200 = polyfit(slip_curve,Fy_curve200,1);
Cf(4) = Cornering_Tire200(1); %cornering stiffness of "front" which is the same as "rear"
%Line fitting 250lb load stiffness
Fy_curve250 = Fy250lbf(3:20,1);
Cornering_Tire250 = polyfit(slip_curve,Fy_curve250,1);
Cf(5) = Cornering_Tire250(1); %cornering stiffness of "front" which is the same as "rear"

% Cornering stiffness vs load data fitting (quadratic)
load_ = [50*4.448 100*4.448 150*4.448 200*4.448 250*4.448];
stiffness_load = polyfit(load_,Cf,2);
%% Calculations
% vy = v*delta/L; % lateral velocity, m/s
% u = sqrt(v.^2-vy.^2);   % longitudinal velocity, m/s
% ax = diff(u,time); % longitudinal accel, m/s^2
% ay = diff(vy,time); % lateral accel, m/s^2
% Fz_FL = (m*g*b/(2*L))+(m*h*ax/(2*L))-(m*h*ay*b/(2*t*L));    % normal force FL, N
% Fz_FR = (m*g*b/(2*L))+(m*h*ax/(2*L))+(m*h*ay*b/(2*t*L));    % normal force FR, N
% Fz_RL = (m*g*a/(2*L))-(m*h*ax/(2*L))-(m*h*ay*b/(2*t*L));    % normal force RL, N
% Fz_RR = (m*g*a/(2*L))-(m*h*ax/(2*L))+(m*h*ay*b/(2*t*L));    % normal force RR, N
% r = vy/L;   % yaw rate, rad/s
% alpha_f = delta - atan((vy+a*r)./u);  % slip angle (front), rad
% alpha_r = - atan((vy-b*r)./u);  % slip angle (rear), rad
% Fy_f = C_alpha_f*alpha_f;   % lateral force (front), N
% Fy_r = C_alpha_r*alpha_r;   % lateral force (rear), N
% Mz = (Tm_rl-Tm_rr)*GR*t/(2*Rw); % corrective yaw moment, Nm
% r_d_driver = u*tan(delta)/L;    % desired yaw based on driver steering input
% r_d_car = u/rho_road;           % desired yaw based on the desired drive line curvature input 
% 
% r_dot = (a*Fy_f - b*Fy_r)/Iz;   % yaw acceleration, rad/s^2

%% Study Settings
% type
study = 1;

% time
t_end = 50;
ts = 0.01;
time = 0:ts:t_end;

% steering and velocity index
v_i = 2;    % 1-15
delta_i = 2;    % 1-15

%% Yaw Dynamics SS - constant speed and steering input study
if study == 1 
    % speed setting (m/s)
    vx_vector = linspace(0,45,15)';
    vx = vx_vector(v_i);
    
    % steering ramp up
    delta_vector = linspace(0,30,15)*(2*pi/180);
    delta = delta_vector(delta_i);
    
    % lateral acceleration
    ay = vx^2/L*tan(delta);
    
    % normal force f/r
    Fz_RR = (m*g*a/(2*L)+m*h*ay*b/(2*t*L))*0.225;
    Fz_RL = (m*g*a/(2*L)-m*h*ay*b/(2*t*L))*0.225;
    Fz_R = mean([Fz_RL Fz_RR]);
    Fz_FL = (m*g*b/(2*L)-m*h*ay*b/(2*t*L))*0.225;
    Fz_FR = (m*g*b/(2*L)+m*h*ay*b/(2*t*L))*0.225;
    Fz_F = mean([Fz_FR Fz_FL]);
    
    % cornering stiffness
    C_yf = polyval(stiffness_load,Fz_F);
    C_yr = polyval(stiffness_load,Fz_R);
    
    % desired yaw rate
    r_d = vx*tan(delta)/L;
    
    % road curvature (radius)
    R = L/tan(delta);

    % initial vy and yaw rate
    vy_0 = vx*delta/L;
    r_0 = vy_0/L;

    % state space model
    a11 = -(C_yf+C_yr)/(m*vx);
    a12 = (-a*C_yf+b*C_yr)/(m*vx)-vx;
    a21 = (-a*C_yf+b*C_yr)/(Iz*vx);
    a22 = -(C_yf*a^2+C_yr*b^2)/(Iz*vx);
    
    A = [a11 a12;a21 a22];
    
    b11 = 0;
    b12 = C_yf/m;
    b21 = 1/Iz;
    b22 = a*C_yf/Iz;
    
    B = [b11 b12;b21 b22];
    C = [1 0;0 1];
    D = [0 0;0 0];
end

%% Yaw Dynamics SS - constant speed and ramping steering input (average cornering stiffness)
if study == 2
    % speed setting (m/s)
    vx_vector = linspace(0,45,15);
    vx = vx_vector(v_i);
    
    % steering ramp up
    delta = (30/t_end)*time*(2*pi/180);
    
    % lateral acceleration
    ay = vx^2/L*tan(delta);
    
    % normal force f/r
    Fz_RR = (m*g*a/(2*L)+m*h*ay*b/(2*t*L))*0.225;
    Fz_RL = (m*g*a/(2*L)-m*h*ay*b/(2*t*L))*0.225;
    Fz_R = mean([Fz_RL Fz_RR]);
    Fz_FL = (m*g*b/(2*L)-m*h*ay*b/(2*t*L))*0.225;
    Fz_FR = (m*g*b/(2*L)+m*h*ay*b/(2*t*L))*0.225;
    Fz_F = mean([Fz_FR Fz_FL]);
    
    % cornering stiffness
    C_yf = polyval(stiffness_load,Fz_F);
    C_yr = polyval(stiffness_load,Fz_R);
    
    % desired yaw rate
    r_d = vx*tan(delta)/L;
    
    % road curvature (radius)
    R = L./tan(delta);
    
    % initial vy and yaw rate
    vy_0 = vx*delta/L;
    r_0 = vy_0/L;

    % state space model
    a11 = -(C_yf+C_yr)/(m*vx);
    a12 = (-a*C_yf+b*C_yr)/(m*vx)-vx;
    a21 = (-a*C_yf+b*C_yr)/(Iz*vx);
    a22 = -(C_yf*a^2+C_yr*b^2)/(Iz*vx);
    
    A = [a11 a12;a21 a22];
    
    b11 = 0;
    b12 = C_yf/m;
    b21 = 1/Iz;
    b22 = a*C_yf/Iz;
    
    B = [b11 b12;b21 b22];
    C = [1 0;0 1];
    D = [0 0;0 0];
end